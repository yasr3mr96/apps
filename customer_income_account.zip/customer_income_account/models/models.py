# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Partner(models.Model):
    _inherit='res.partner'
    custom_income_account_id = fields.Many2one(
        comodel_name='account.account',
        string='Custom Income Account',
        required=False)
class MoveLine(models.Model):
    _inherit='account.move.line'

    @api.depends('display_type', 'company_id','partner_id')
    def _compute_account_id(self):
        for line in self:
            if line.partner_id and line.partner_id.custom_income_account_id and\
                    line.move_id.is_sale_document(include_receipts=True) and \
                    line.display_type == 'product' and line.move_id.is_invoice(True):
                line.account_id=line.partner_id.custom_income_account_id.id
            else:
                super()._compute_account_id()


