# -*- coding: utf-8 -*-
{
    'name': "customer_income_account",
    'depends': ['base','account'],
    'data': [
        'views/views.xml',
    ],

}
